<?php $__currentLoopData = $changoPendiente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $lugarTemporal = $pp->lugarTemporal;
    $lugar1 = $pp->nombreCliente;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>

<div class="modal fade" id="staticBackdrop" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Carrito de compras</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <button type="button" class="btn btn-success btn-lg btn-block" id="botonNewChango"> Nuevo carro </button>

            <div class="border-top mt-4 text-center"> <b>Carros empezados: </b></div>

                <?php $__currentLoopData = $changoProceso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('chango', $item)); ?>">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item" aria-current="page">Carro N°: <?php echo e($item->id); ?></li>
                <li class="breadcrumb-item active" aria-current="page">Cliente: <?php echo e($item->cliente->nombreCliente); ?></li>
              </ol>
            </nav></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

      </div>
    </div>
  </div>
</div>

<div class="container">    
  
    <div class="row justify-content-center align-items-center">

        <button 
        type="button" 
        class="mb-2 text-center text-white border rounded-circle bg-success d-flex justify-content-center flex-wrap" 
        data-toggle="modal" 
        data-target="#staticBackdrop" 
        style="width:220px; height:220px;">

                    <h1 class="display-1 align-self-center"> $  </h1>
                    <p  class="" style="width: 100%; font-size:110%;"> NUEVA VENTA </p> 

        </button>

    <a href="<?php echo e(route('wonderlist')); ?>"> 
        <div class="
            mb-2 
            text-center text-white 
            border rounded-circle bg-primary d-flex 
            justify-content-center flex-wrap" 
            style="width:200px; height:200px; ">
                    <img src="/img/casa.png" class="align-self-center" style="max-width: 40%"> 
                    <p  class="" style="width: 100%; font-size:110%;"> 
                        WONDERLIST <br> (stock y precios) 
                    </p> 
        </div> </a>

        <a href="<?php echo e(route('ventas')); ?>"> 
            <div class=" 
            mb-2 
            text-center text-white 
            border rounded-circle bg-primary d-flex 
            justify-content-center flex-wrap" 
            style="width:180px; height:180px;">
                    <h1 class="display-1 align-self-center"> $  </h1>
                    <p  class="" style="width: 100%; font-size:110%;"> VER VENTAS </p> 
            </div> </a>


            <a href="<?php echo e(route('clientes')); ?>"> 
              <div class="
                  mb-2 
                  text-center text-white 
                  border rounded-circle bg-primary d-flex 
                  justify-content-center flex-wrap" 
                  style="width:180px; height:180px; ">
                          <img src="/img/cliente.png" class="align-self-center" style="max-width: 55%"> 
                          <p  class="" style="width: 100%; font-size:110%;"> 
                              CLIENTES
                          </p> 
              </div> </a>



            <div class="container mt-3">
                <div class="text-center mt-1"> <h3 class="bg-warning text-dark p-2"> Entregas pendientes </h3></div>
                <div class="p-2">
                  <?php $__currentLoopData = $changoPendiente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                          <?php if($item->lugarTemporal == '' OR $item->lugarTemporal == 'null'): ?>
                              <?php
                                $lugarEntrega = $item->cliente->lugar.' - '.$item->cliente->lugarDos
                              ?>
                          <?php else: ?>
                              <?php
                                $lugarEntrega = $item->lugarTemporal;
                              ?>
                          <?php endif; ?>

                  <a href="<?php echo e(route('chango', $item)); ?>">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item" aria-current="page"><b> Cliente: <?php echo e($item->cliente->nombreCliente); ?> </b></li>
                  <li class="breadcrumb-item active" aria-current="page"> <b> <?php echo e($lugarEntrega); ?> </b></li>
                </ol>
              </nav>
                </a>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>


            <div class="container mt-5 border-dark border-top pt-5 ">
              <div class="text-center"> <h3 class="bg-danger text-white p-2"> Poco stock </h3></div>
                <div class="card-body">
                  
                      <div class="mb-5">
                        <h4 class="text-center border p-1 breadcrumb"> Industriales </h4>
                            <?php $__currentLoopData = $faltanteIndustrial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex bd-highlight text-dark border-top border-bottom border-dark p-2 mt-2">
                                  <div class="flex-fill">
                                      <?php echo e($producto->marca); ?><br>
                                      <?php echo e($producto->tipo); ?>

                                  </div>
                                  <div class="flex-fill text-right">
                                    <ins>Stock </ins><br>
                                      <b><?php echo e($producto->stock); ?></b>
                                  </div>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                  
                      <div class="mb-5">
                        <h4 class="text-center border p-1 breadcrumb">Artesanales</h4>
                              <?php $__currentLoopData = $faltanteArtesanal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="d-flex bd-highlight text-dark border-top border-bottom border-dark p-2 mt-2">
                                  <div class="flex-fill bd-highlight">
                                      <?php echo e($producto->marca); ?><br>
                                      <?php echo e($producto->tipo); ?>

                                  </div>
                                  <div class="flex-fill bd-highlight text-right">
                                    <ins>Stock</ins><br>
                                      <b><?php echo e($producto->stock); ?></b>
                                  </div>
                              </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>

                      <div class="mb-5">
                        <h4 class="text-center border p-1 breadcrumb">Otros productos</h4>
                                <?php $__currentLoopData = $faltanteOtro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex bd-highlight text-dark border-top border-bottom border-dark p-2">
                                  <div class="flex-fill bd-highlight">
                                      <?php echo e($producto->marca); ?><br>
                                      <?php echo e($producto->tipo); ?>

                                  </div>
                                  <div class="flex-fill bd-highlight text-right">
                                    <ins>Stock</ins><br>
                                      <b><?php echo e($producto->stock); ?></b>
                                  </div>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                      
                </div>
            </div>
        </div>



    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/pruebas/edit.js"></script>
<script src="/js/wonderlist.js"></script>
<script src="/js/chango.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/home.blade.php ENDPATH**/ ?>