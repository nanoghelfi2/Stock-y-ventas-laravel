<?php
    $precioFinal = 0;
    $productosEnviar = '';
?>

<?php $__currentLoopData = $datosChango; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $changoID): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $changoID->wonderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
    <tr>
        <td class="align-middle">
            <form action="<?php echo e(route('chango.borrar.producto', $changoID->id)); ?> " method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="estadoVenta" value="<?php echo e($changoID->estadoVenta); ?>">
            <input type="hidden" name="idPivote" value="<?php echo e($producto->pivot->id); ?>">
            <input type="hidden" name="idWonder" value="<?php echo e($producto->pivot->wonderlist_id); ?>">
            <input type="hidden" name="cantidad" value="<?php echo e($producto->pivot->cantidad); ?>">
            <input type="hidden" name="unidades" value="<?php echo e($producto->pivot->unidades); ?>">
                <button class="btn btn-danger btn-sm rounded-circle"> 
                    X 
                </button>
            </form>
        </td>

        <th class="align-middle"> <?php echo e($marca= $producto->marca); ?> <br> <?php echo e($tipo= $producto->tipo); ?> </td>
        <td class="text-center align-middle"> <?php echo e($cantidades= $producto->pivot->cantidad); ?> un.  <br> <?php echo e($producto->pivot->unidades); ?> </td>
        <td class="text-center align-middle"> $ <?php echo e($producto->pivot->subtotal); ?> </td>
    </tr>
    </tbody>
        <?php
            $productosEnviar .= '<li>'.$marca.' ('.$tipo.') -> '.$cantidades.'</li>';
            $precioFinal += $producto->pivot->subtotal;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/chango/listaProductos.blade.php ENDPATH**/ ?>