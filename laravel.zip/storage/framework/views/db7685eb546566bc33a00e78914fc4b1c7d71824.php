

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center"> <?php echo e(session('success')); ?>  </div>
<?php endif; ?>

<div class="container mb-4">
    <a href="<?php echo e(route('wonderlist.agregar')); ?>" class="btn btn-success btn-block"> Agregar nuevo producto </a>
</div>

<div id="deseaBorrar" class="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

</div>


<div class="container mb-3 border-top border-bottom">
  <form action="wonderlist"></form>
  <p> Seleccione una marca: </p>
  <select name="" id="filtro-marca" class="form-control"> 
    <option value="todas"> Todas </option>
          <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $select1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($select1->marca); ?>"> <?php echo e($select1->marca); ?> </option>                
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <a href="/wonderlist/filtro/todas" class="btn btn-primary btn-block mt-2 mb-2" id="anclaFiltro">
      Filtrar
  </a>
</div>

<div class="">
<table class="table table-striped ">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Marca <br> Tipo </th>
        <th scope="col"> $ Unid. <br> $ Pack</th>
        <th scope="col"> Stock </th>
        <th scope="col"> Acciones </th>
      </tr>
    </thead>
    <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr class="align-middle">
        <div>
          <th scope="row" class="align-middle"><a href="<?php echo e(route ('wonderlist.ver', $item->id)); ?>"> <b> <?php echo e($item->marca); ?> </b><br> <?php echo e($item->tipo); ?> </a></th>
          <td class="align-middle">$ <?php echo e($item->precioVenta); ?> <br> $ <?php echo e($item->precioPack); ?> </td> 
          <td class="text-center align-middle"><?php echo e($item->stock); ?></td>
          <td> 
              <a href="<?php echo e(route('wonderlist.editar', $item->id)); ?>" class="btn-sm btn-warning btn-block text-center"> 
                  Editar 
              </a> 
        
              <button class="btn-sm btn-danger btn-block text-center botonBorrar" value="<?php echo e($item->id); ?>" data-toggle="modal" data-target="#deseaBorrar">
                Borrar 
              </button>
          </td>
      </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/pruebas/edit.js"></script>
<script src="/js/wonderlist.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/wonderlist.blade.php ENDPATH**/ ?>