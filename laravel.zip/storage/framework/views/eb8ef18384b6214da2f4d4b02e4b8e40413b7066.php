

<?php $__env->startSection('main'); ?>

<h1> Toda la Prueba </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/prueba.blade.php ENDPATH**/ ?>