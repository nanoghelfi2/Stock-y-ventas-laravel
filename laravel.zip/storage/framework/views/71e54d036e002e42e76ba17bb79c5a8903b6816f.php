


<?php $__env->startSection('content'); ?>
<?php
   $costoActual = $verProducto->precioCompra;
?>

<?php switch($verProducto->unidadCompra):

    case ($verProducto->unidadCompra == 'unidad'): ?>
            <?php
        $precio1 = 'Precio x unidad: $ '.$costoActual;     
        $precio6 = 'Precio x pack (6): $ '.$costoActual * 6;
        $precio24 = 'Precio x pack (24): $ '.$costoActual * 24; 
            ?>
        <?php break; ?>

    <?php case ($verProducto->unidadCompra == 'sixpack'): ?>
            <?php
        $precio1 = 'Precio x unidad: $ '.$costoActual / 6;   
        $precio6 = 'Precio x pack (6): $ '.$costoActual;         
        $precio24 = 'Precio x pack (24): $ '.$costoActual * 4;   
            ?> 
        <?php break; ?>

    <?php case ($verProducto->unidadCompra == 'pack24'): ?>
            <?php
        $precio1 = 'Precio x unidad: $ '.$costoActual / 24; 
        $precio6 = 'Precio x pack (6): $ '.$costoActual / 4;   
        $precio24 = 'Precio x pack (24): $ '.$costoActual;               
            ?>
        <?php break; ?>

    <?php case ($verProducto->unidadCompra == 'otro'): ?>    
            <?php
        $precio1 = 'No se detecto la unidad de compra'; 
        $precio6 = 'Su valor de costo es de:';   
        $precio24 = '$ '.$costoActual;             
            ?>
        <?php break; ?>
<?php endswitch; ?> 


<div class="container">
    <center> <a href="<?php echo e(route('wonderlist')); ?>" class="btn btn-info mb-3"> Volver al <b> Wonderlist </b>  </a> </center>

<h2 class="text-center"> <?php echo e($verProducto->marca); ?> </h2>
<h3 class="text-center border-bottom"> <?php echo e($verProducto->tipo); ?> </h3>
<p style="font-size:120%;"><b>Stock disponible:</b> <?php echo e($verProducto->stock); ?> unidades</p>


<b style="font-size:120%;"> Precio de COSTO: </b>
<p> <?php echo e($precio1); ?>  <br>
    <?php echo e($precio6); ?><br>
    <?php echo e($precio24); ?> </p>

<b style="font-size:120%;"> Precio para la venta:</b>
    <p class=""> Precio x unidad: $ <?php echo e($verProducto->precioVenta); ?> <br>
     Precio x pack (6): $ <?php echo e($verProducto->precioPack); ?></p>

<p class=""> Categoria actual: <?php echo e($verProducto->tipoCerveza); ?>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/wonderlist.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/wonderlist/ver.blade.php ENDPATH**/ ?>