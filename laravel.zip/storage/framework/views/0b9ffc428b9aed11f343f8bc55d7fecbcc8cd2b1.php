
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">¿Seguro que quiere borrar este producto?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <?php $__currentLoopData = $productoEliminar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <b> <?php echo e($item->marca); ?></b> <br>
          <p><?php echo e($item->tipo); ?></p>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="modal-footer">
          <a href="<?php echo e(route('wonderlist')); ?>" class="btn btn-secondary">No</a>

          <form action="<?php echo e(route('wonderlist.borrar', $item->id)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger" type="submit">Si, Borrar</button> 
          </form>

        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/wonderlist/modal.blade.php ENDPATH**/ ?>