

<?php $__env->startSection('content'); ?>
<center> <a href="<?php echo e(route('wonderlist')); ?>" class="btn btn-info mb-3"> Volver al <b> Wonderlist </b>  </a> </center>

<h3 class="text-center border-bottom border-top"> Agregar un nuevo producto </h3>


<form action="<?php echo e(route('agregar.enviar')); ?>" method="POST" style="margin-bottom:30%;"> 
<?php echo csrf_field(); ?>  

<?php if(session('success')): ?>
    <div class="alert alert-success d-flex justify-content-between align-items-center"> <?php echo e(session('success')); ?>  
    <a href="<?php echo e(route('wonderlist')); ?>" class="btn btn-success"> Volver al Wonderlist </a></div>
<?php endif; ?>

<?php if(session('Error')): ?>
    <div class="alert alert-danger"> <?php echo e(session('Error')); ?> </div>
<?php endif; ?>

<?php $__errorArgs = ['existenteMarca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> Debe seleccionar una Marca </div>  
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['nuevoTipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"> Debe escribir un Tipo </div>  
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


<div class="container mt-3 border-bottom border-secondary">
    <div class="form-group">
    <h4> Marca: </h4>

        <b>Seleccione una marca existente: </b>
        <select class="form-control"  name="existenteMarca" id="marcaExistente"> 
            <option value=""  ></option>
                <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->marca); ?>"> <?php echo e($item->marca); ?> </option>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <b>O escriba una nueva marca:</b>
        <input type="text" class="form-control"  name="nuevaMarca" value="<?php echo e(old('nuevaMarca')); ?>"> 

    </div>
</div>

<div class="container mt-2 mb-2 border-bottom border-secondary">  
        <div class="form-group">
        <h4> Tipo: </h4>
            <b>Escriba un tipo:</b>
            <input type="text" class="form-control" name="nuevoTipo" value="<?php echo e(old('nuevoTipo')); ?>"> 

        </div>
</div>

<div class="container">
        <div class="form-group mb-3">


            <b>Precio de costo:</b>
            <input type="number" class="form-control" name="precioCompra" value="<?php echo e(old('precioCompra')); ?>"> 

            <select class="form-control mb-3" name="unidadCompra"> 
                <option value="" > Seleccione una unidad </option>
                <option value="unidad">     Unidad </option>
                <option value="sixpack">    Pack de 6 </option>
                <option value="pack24">     Pack de 24 </option>
                <option value="otro">     Otro </option>
            </select>


        </div>
        <div class="form-group mt-4">

            <b>Precio venta por unidad:</b>
            <input type="number" class="form-control mb-4" name="precioVenta" id="inputPrecioUnidad" value="<?php echo e(old('precioVenta')); ?>" min="0"> 

            <b>Precio venta por pack (x 6):</b>
            <input type="number" class="form-control mb-4" name="precioPack" id="inputPrecioPack" value="<?php echo e(old('precioPack')); ?>" min="0"> 

            <b>Stock:</b>
            <input type="number" class="form-control mb-4" name="stock" value="<?php echo e(old('stock')); ?>" min="0"> 

            <b>Tipo:</b>
            <select class="form-control" name="tipoCerveza"> 
                <option value=""> Seleccione un estilo de producto </option>
                <option value="artesanal"> Artesanal </option>
                <option value="industrial"> Industrial </option>
                <option value="otro"> Otros </option>
            </select>

            
        </div>
</div>
<center><button class="btn btn-primary btn-lg" type="submit"> Agregar producto </button></center>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/wonderlist.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/wonderlist/agregar.blade.php ENDPATH**/ ?>