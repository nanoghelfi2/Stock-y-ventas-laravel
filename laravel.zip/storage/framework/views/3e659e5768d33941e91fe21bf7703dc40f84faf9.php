

<div class="modal-header">
<?php $__currentLoopData = $verVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h5 class="modal-title" id="exampleModalLabel">ID de la venta: <?php echo e($vv->id); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <h5> Cliente: <?php echo e($vv->nombreCliente); ?> </h5>
        <div style="font-size:110%;">
            <b> Fecha: </b> <?php echo e($vv->fecha); ?> <br>
            <b> Lugar de entrega: </b> <?php echo e($vv->lugar); ?> <br>
            <b> Valor total: $ <?php echo e($vv->valorVenta); ?></b> <br>
            <center> <b> Productos: </b> <br> <?php  echo $vv->productosVendidos ?> </center>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
      </div>



<?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/venta/venta.blade.php ENDPATH**/ ?>