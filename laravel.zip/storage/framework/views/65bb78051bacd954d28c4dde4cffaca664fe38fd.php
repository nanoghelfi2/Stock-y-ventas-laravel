<?php $__currentLoopData = $mostrarCliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
  $idCliente = $as->id; 
?>

<div class="modal-header">
    <form action="<?php echo e(route('cliente.borrar', $idCliente)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger mr-4">Borrar cliente</button>
    </form>

    <h5 class="modal-title align-middle mt-2" id="exampleModalLabel">Datos del cliente</h5> 

    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
</div>

<form action="<?php echo e(route('cliente.editar', $idCliente)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
  <div class="modal-body">
    <b>Nombre:</b>      <input type="text" name="nombre" value="<?php echo e($as->nombreCliente); ?>" class="form-control"> <br>
    <b>Contacto:</b>    <input type="text" name="contacto" value="<?php echo e($as->contacto); ?>" class="form-control">      <br>
    <b>Contacto 2:</b>  <input type="text" name="contactoDos" value="<?php echo e($as->contactoDos); ?>" class="form-control">   <br>
    <b>Localidad:</b>   <input type="text" name="lugar" value="<?php echo e($as->lugar); ?>" class="form-control">         <br>
    <b>Calles:</b>      <input type="text" name="lugarDos" value="<?php echo e($as->lugarDos); ?>" class="form-control">
  </div>
  <div class="modal-footer">

    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

    <button type="submit" class="btn btn-warning" value="<?php echo e($as->id); ?>">Editar </button>
    </form>


  </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel\stocklaravel\resources\views/cliente/modal.blade.php ENDPATH**/ ?>