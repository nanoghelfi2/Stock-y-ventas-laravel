$(function(){
    alert('script cargado');
    console_log('hola mundo');
});